#include "pch.h"
#include "List.h"

#include <iostream>

class List
{
private:
    struct Node
    {
        int data;
        Node* next;
        Node(int val) : data(val), next(nullptr) {}
    };

    Node* header = nullptr;
    int size = 0;

public:
    // Agregar un elemento al final de la lista
    void Add(int item)
    {
        Node* newNode = new Node(item);
        if (!header)
        {
            header = newNode;
        }
        else
        {
            Node* current = header;
            while (current->next)
            {
                current = current->next;
            }
            current->next = newNode;
        }
        size++;
    }

    // Borrar todos los elementos de la lista
    void Clear()
    {
        while (header)
        {
            Node* temp = header;
            header = header->next;
            delete temp;
        }
        size = 0;
    }

    // Obtener la cantidad de elementos en la lista
    int Count()
    {
        return size;
    }

    // Verificar si la lista contiene un elemento dado
    bool Contains(int item)
    {
        Node* current = header;
        while (current)
        {
            if (current->data == item)
            {
                return true;
            }
            current = current->next;
        }
        return false;
    }

    // Obtener el �ndice de la primera aparici�n de un elemento
    int Index(int item)
    {
        int index = 0;
        Node* current = header;
        while (current)
        {
            if (current->data == item)
            {
                return index;
            }
            current = current->next;
            index++;
        }
        return -1;  // Elemento no encontrado
    }

    // Insertar un elemento en un �ndice espec�fico
    void Insert(int index, int item)
    {
        if (index < 0 || index > size)
        {
            std::cerr << "�ndice fuera de rango." << std::endl;
            return;
        }

        Node* newNode = new Node(item);
        if (index == 0)
        {
            newNode->next = header;
            header = newNode;
        }
        else
        {
            Node* current = header;
            for (int i = 1; i < index; i++)
            {
                current = current->next;
            }
            newNode->next = current->next;
            current->next = newNode;
        }
        size++;
    }

    // Obtener el elemento en un �ndice espec�fico
    int GetItem(int index)
    {
        if (index < 0 || index >= size)
        {
            std::cerr << "�ndice fuera de rango." << std::endl;
            return -1;  // Valor predeterminado en caso de error
        }

        Node* current = header;
        for (int i = 0; i < index; i++)
        {
            current = current->next;
        }
        return current->data;
    }

    // Establecer el elemento en un �ndice espec�fico
    void SetItem(int index, int item)
    {
        if (index < 0 || index >= size)
        {
            std::cerr << "�ndice fuera de rango." << std::endl;
            return;
        }

        Node* current = header;
        for (int i = 0; i < index; i++)
        {
            current = current->next;
        }
        current->data = item;
    }

    // Obtener el �ndice de la �ltima aparici�n de un elemento
    int LastIndex(int item)
    {
        int lastIndex = -1;
        int index = 0;
        Node* current = header;
        while (current)
        {
            if (current->data == item)
            {
                lastIndex = index;
            }
            current = current->next;
            index++;
        }
        return lastIndex;
    }

    // Eliminar la primera aparici�n de un elemento
    bool Remove(int item)
    {
        if (!header)
        {
            return false;  // La lista est� vac�a
        }

        if (header->data == item)
        {
            Node* temp = header;
            header = header->next;
            delete temp;
            size--;
            return true;
        }

        Node* current = header;
        while (current->next)
        {
            if (current->next->data == item)
            {
                Node* temp = current->next;
                current->next = current->next->next;
                delete temp;
                size--;
                return true;
            }
            current = current->next;
        }

        return false;  // Elemento no encontrado
    }

    // Eliminar el elemento en un �ndice espec�fico
    void RemoveAt(int index)
    {
        if (index < 0 || index >= size)
        {
            std::cerr << "�ndice fuera de rango." << std::endl;
            return;
        }

        if (index == 0)
        {
            Node* temp = header;
            header = header->next;
            delete temp;
        }
        else
        {
            Node* current = header;
            for (int i = 1; i < index; i++)
            {
                current = current->next;
            }
            Node* temp = current->next;
            current->next = current->next->next;
            delete temp;
        }
        size--;
    }
};

int main()
{
    List myList;
    myList.Add(1);
    myList.Add(2);
    myList.Add(3);

    std::cout << "Element at index 1: " << myList.GetItem(1) << std::endl;
    std::cout << "Contains 2: " << myList.Contains(2) << std::endl;
    myList.Remove(2);
    std::cout << "After removing 2, Contains 2: " << myList.Contains(2) << std::endl;

    return 0;
}
